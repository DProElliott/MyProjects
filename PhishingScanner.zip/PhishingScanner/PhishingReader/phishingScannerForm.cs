﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhishingReader
{
    public partial class phishingScannerForm : Form
    {   // Common Phishing Keywords - Word Bank
       string[] phishingKeywords = new string[30]{ "account", "urgent", "important", "bank", "payment", "re:", "reply", "delivery",
            "password", "changed", "email", "paypal", "score", "free", "amazon", "loan", "cbd", "medicare", 
            "social",  "security", "credit", "card", "cash", "rewards", "emergency", "timeshare", "congratulations", "secure", "savings", "discount" };

        string scoreThreshold; // String Variable to Output Feedback to the User
        int wordCounter = 0; // Score

    public phishingScannerForm()
        {
            InitializeComponent();
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            EmailText.Text = String.Empty;
            ResultsLabel.Text = " "; // Resets the Label that holds the Score
            thresholdLabel.Text = " "; // Resets the Label that holds the Feedback
            wordCounter = 0; // Resets Score Count Back to 0
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            ResultsLabel.Text = " "; // Ensures that the score doesn't get added to the previous calculated score 
            wordCounter = 0;        // By resetting it back to 0 each time the user clicks Submit

            EmailText.Text = EmailText.Text.ToLower(); // Forces what the user puts into the textbox into Lowercase to avoid any issues with casing
            string[] EmailArray = EmailText.Text.Split(new char[] { ' ' }); // Splits each word the user puts in the textbox and 
                                                                            // individually stores in the array rather than as one entire element
            for (int i = 0; i < EmailArray.Length; i++) 
            {
                for(int k = 0; k < phishingKeywords.Length; k++) // Loop compares each word in the GUI textbox with each word in the Word Bank
                {
                    if(EmailArray[i] == phishingKeywords[k]) // If it matches one of the words, it increments the score by a designated amount
                    {
                        if (EmailArray[i] == "account")
                        {
                            wordCounter = wordCounter + 4;
                        }
                        if (EmailArray[i] == "paypal")
                        {
                            wordCounter = wordCounter + 2;
                        }
                        if (EmailArray[i] == "urgent")
                        {
                            wordCounter = wordCounter + 7;
                        }
                        if (EmailArray[i] == "important")
                        {
                            wordCounter = wordCounter + 7;
                        }
                        if (EmailArray[i] == "bank")
                        {
                            wordCounter = wordCounter + 5;
                        }
                        if (EmailArray[i] == "password")
                        {
                            wordCounter = wordCounter + 3;
                        }
                        if (EmailArray[i] == "credit")
                        {
                            wordCounter = wordCounter + 6;
                        }
                        if (EmailArray[i] == "loan")
                        {
                            wordCounter = wordCounter + 7;
                        }
                        if (EmailArray[i] == "cbd")
                        {
                            wordCounter = wordCounter + 8;
                        }
                        if (EmailArray[i] == "security")
                        {
                            wordCounter = wordCounter + 6;
                        }
                        if (EmailArray[i] == "congratulations")
                        {
                            wordCounter = wordCounter + 9;
                        }
                        if (EmailArray[i] == "savings")
                        {
                            wordCounter = wordCounter + 6;
                        }
                        else // If the word triggered isn't one of the above more common phishing words, then it just defaults to increment the score by 1
                        {
                            wordCounter++;
                        }
                    }
                }
            }
            
            if (wordCounter < 10) // If the Score is under 10, then this string gets output below the Score label
            {
                scoreThreshold = "This Email is NOT a scam";
            }
            if (wordCounter > 10) // and so on...
            {
                scoreThreshold = "This Email is suspicous";
            }
            if (wordCounter > 30)
            {
                scoreThreshold = "This Email is a potential scam";
            }
            if (wordCounter > 50)
            {
                scoreThreshold = "This Email is a scam";
            }

            ResultsLabel.Text = "This Email has a score of: " + wordCounter.ToString(); // Outputs Score to the GUI
            thresholdLabel.Text = scoreThreshold; // Outputs the Feedback Message depending on the Score
        }
    }
}
