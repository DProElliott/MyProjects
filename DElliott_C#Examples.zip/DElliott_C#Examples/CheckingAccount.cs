﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam
{
    class CheckingAccount : Account
    {
        private decimal feeCharge;

        public CheckingAccount(decimal fee, decimal balance)
            : base(balance)
        {
            feeCharge = fee;
        }

        public decimal FeeCharge
        {
            get
            {
                return feeCharge;
            }
            set
            {
                if (value >= 0)
                {
                    feeCharge = value;
                }
            }
        }

        public override decimal Credit()
        {
            return AccountBalance = base.Credit() - feeCharge ;
        }

        public override decimal Debit()
        {
            return AccountBalance =  base.Debit() - withdrawDebit;
        }

        public override string ToString()
        {
            return string.Format("{0}", AccountBalance);
        }
    }

}
