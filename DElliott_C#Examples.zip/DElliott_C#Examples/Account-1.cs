﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam
{
    class Account
    {
        private decimal accountBalance;
        private decimal addAmount;
        private decimal withdraw;

        public Account(decimal balance)
        {
            AccountBalance = balance;
        }

        public decimal AccountBalance
        {
            get
            {
                return accountBalance;
            }
            set
            {
                if (value >= 0)
                {
                    accountBalance = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Account balance", value, "must be greater than 0.0");
                }
            }
        }

        public decimal addCredit
        {
            get
            {
                return addAmount;
            }
            set
            {
                if (value >= 0)
                {
                    addAmount = value;
                }
            }
        }

        public decimal withdrawDebit
        {
            get
            {
                return withdraw;
            }
            set
            {
                if (value >= 0)
                {
                    withdrawDebit = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("must withdraw more than 0.0 Dollars");
                }

                if (withdraw > accountBalance)
                {
                    throw new ArgumentOutOfRangeException("Debit amount exceeded account balance.");
                }
            }
        }


        public virtual decimal Credit()
        {
            return addAmount + accountBalance;
        }

        public virtual decimal Debit()
        {
            return accountBalance - withdraw;


        }

        public decimal currentBalance
        {
            get
            {
                return accountBalance;
            }
        }

        public override string ToString()
        {
            return string.Format("{0}", accountBalance);
        }
    }

}
