﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam
{
    class AccountTest
    {
        static void Main(string[] args)
        {
            Account account1 = new Account(1000);
            CheckingAccount checking1 = new CheckingAccount(30, 1000);
            SavingsAccount savings1 = new SavingsAccount(5, 1000);
            


            savings1.CalculateInterest();

            checking1.Credit();

            Console.WriteLine("The new Account Balance is {0}", checking1.ToString());
        }
    }
}
