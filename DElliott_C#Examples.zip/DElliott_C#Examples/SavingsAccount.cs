﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalExam
{
    class SavingsAccount : Account
    {
        private decimal interestRate;
        private decimal interestEarned;

        public SavingsAccount(decimal rate, decimal balance)
            : base(balance)
        {
            InterestRate = rate;
        }

        public decimal InterestRate
        {
            get
            {
                return interestRate;
            }
            set
            {
                if(value >= 0)
                {
                    interestRate = value;
                }
            }
        }

        public void CalculateInterest()
        {
            interestEarned = interestRate * AccountBalance;
        }
    }
}
